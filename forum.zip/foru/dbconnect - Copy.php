<?php
//script to connect to the database
$servername="localhost";
$username="root";
$password="";
$database="forum";
$connecting=mysqli_connect($servername,$username,$password,$database);
?>