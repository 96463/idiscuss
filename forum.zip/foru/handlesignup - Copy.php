<?php
$showError="false";
if($_SERVER["REQUEST_METHOD"]=="POST")
{
     require 'dbconnect.php';
     $user_email=$_POST['signupEmail'];
     $pass=$_POST['signupPassword'];
     $cpass=$_POST['signupcPassword'];
     //check wheather this email is exist
     $existSql="select * from `user` where user_email='$user_email'";
     $result=mysqli_query($connecting,$existSql);
     $numRows=mysqli_num_rows($result);
     if($numRows>0)
     {
       $showError="true";
         $showError="Email already in use";
     }
     else{
         if($pass=$cpass)
         {
             $hash=password_hash($pass,PASSWORD_DEFAULT);
             $sql="INSERT INTO `user` ( `user_email`, `password`) VALUES ( '$user_email', '$hash')";
             $result=mysqli_query($connecting,$sql);
             if($result)
             {
                 $showAlert=true;
                 header("Location:index.php?signupsuccess=true");
                 exit();
             }
         }
         else
         {
             $showError="password do not match";
             
         }
     }
     header("Location:index.php?signupsuccess=false&error=$showError");

     }
?>