<div class="container-fluid bg-dark text-light">
<p class="text-center py-3 mb-0">copyright iDiscuss-2021|ALL rights reserved</p>
</div>