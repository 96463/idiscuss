<?php
$showError="false";
if($_SERVER["REQUEST_METHOD"]=="POST")
{
    require 'dbconnect.php';
    $email=$_POST['loginEmail'];
    $pass=$_POST['loginPass'];
    $sql="SELECT * FROM `user` where user_email='$email'";
    $result=mysqli_query($connecting,$sql);
    $numRows=mysqli_num_rows($result);
    if($numRows==1)
    {
        $row=mysqli_fetch_assoc($result);
            if(password_verify($pass,$row['password']))
            {
                session_start();
                $_SESSION['loggedin']=true;
                $_SESSION['sno']=$row['sno'];
                $_SESSION['useremail']=$email;
                echo"logged in" .$email;
            }
            header("Location: index.php");
    }
    header("Location: index.php");

}
?>